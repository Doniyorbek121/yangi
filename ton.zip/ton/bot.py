import telebot
from telebot import types
import time
import threading
import requests

# Bot sozlamalari
BOT_TOKEN = "7253489362:AAED1JWz195gwPLp6aKk6_zGOxOknwRMNbM"
PREMIUM_NARXI = 5  # Premium obuna uchun Telegram Stars miqdori
ADMIN_IDS = [6126131161]  # O'zingizning Telegram IDingizni qo'ying

# Foydalanuvchi ma'lumotlari (asl botda bazadan foydalanish yaxshiroq)
user_data = {}
admin_buyruqlari = {
    "stats": "Bot statistikasini ko'rsatish",
    "broadcast": "Barcha foydalanuvchilarga xabar yuborish",
    "add_premium": "Foydalanuvchiga premium berish"
}

bot = telebot.TeleBot(BOT_TOKEN)


def webhookni_ochir():
    """Polling ishlashi uchun mavjud webhookni o'chirish"""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/deleteWebhook"
        javob = requests.get(url)
        if javob.status_code == 200:
            print("Webhook muvaffaqiyatli o'chirildi")
        else:
            print(f"Webhookni o'chirib bo'lmadi: {javob.text}")
    except Exception as xato:
        print(f"Webhookni o'chirishda xato: {xato}")


# Yordamchi funksiyalar
def foydalanuvchi_tilini_ol(chat_id):
    return user_data.get(chat_id, {}).get('til', "🇺🇿 O'zbekcha")


def tarjima_ol(kalit, til):
    tarjimalar = {
        "xush_kelibsiz": {
            "🇺🇿 O'zbekcha": "Xush kelibsiz! Quyidagi menyudan tanlang:",
            "🇷🇺 Русский": "Добро пожаловать! Выберите из меню:",
            "🇬🇧 English": "Welcome! Please choose from the menu:"
        },
        "premium_tugmasi": {
            "🇺🇿 O'zbekcha": "💳 Premium obuna",
            "🇷🇺 Русский": "💳 Премиум подписка",
            "🇬🇧 English": "💳 Premium subscription"
        },
        "videolar_tugmasi": {
            "🇺🇿 O'zbekcha": "🎥 Videolar",
            "🇷🇺 Русский": "🎥 Видео",
            "🇬🇧 English": "🎥 Videos"
        }
    }
    return tarjimalar.get(kalit, {}).get(til, kalit)


# Tilni tanlash handleri
@bot.message_handler(commands=['start'])
def xush_kelibsiz(message):
    # Til tanlash tugmalari
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn_uz = types.KeyboardButton("🇺🇿 O'zbekcha")
    btn_ru = types.KeyboardButton("🇷🇺 Русский")
    btn_en = types.KeyboardButton("🇬🇧 English")
    markup.add(btn_uz, btn_ru, btn_en)

    bot.reply_to(message, "Iltimos, tilni tanlang / Пожалуйста, выберите язык / Please select language:",
                 reply_markup=markup)


# Til tanlash
@bot.message_handler(func=lambda message: message.text in ["🇺🇿 O'zbekcha", "🇷🇺 Русский", "🇬🇧 English"])
def tilni_ornat(message):
    til = message.text
    chat_id = message.chat.id

    if chat_id not in user_data:
        user_data[chat_id] = {'qoshilgan_sana': time.time(), 'premium': False}
    user_data[chat_id]['til'] = til

    # Asosiy menyu
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton(tarjima_ol("premium_tugmasi", til))
    btn2 = types.KeyboardButton(tarjima_ol("videolar_tugmasi", til))
    markup.add(btn1, btn2)

    bot.send_message(chat_id, tarjima_ol("xush_kelibsiz", til), reply_markup=markup)


# Video kategoriyalari menyusi
@bot.message_handler(func=lambda message: message.text in ["🎥 Videolar", "🎥 Видео", "🎥 Videos"])
def video_kategoriyalarini_korsat(message):
    chat_id = message.chat.id
    til = foydalanuvchi_tilini_ol(chat_id)

    tarjimalar = {
        "kategoriyalar": {
            "🇺🇿 O'zbekcha": "Video kategoriyalar:",
            "🇷🇺 Русский": "Категории видео:",
            "🇬🇧 English": "Video categories:"
        },
        "oddiy": {
            "🇺🇿 O'zbekcha": "📹 Oddiy video",
            "🇷🇺 Русский": "📹 Обычное видео",
            "🇬🇧 English": "📹 Regular video"
        },
        "kattalar": {
            "🇺🇿 O'zbekcha": "🔞 18+ video",
            "🇷🇺 Русский": "🔞 18+ видео",
            "🇬🇧 English": "🔞 18+ video"
        },
        "pro": {
            "🇺🇿 O'zbekcha": "💎 Pro video",
            "🇷🇺 Русский": "💎 Pro видео",
            "🇬🇧 English": "💎 Pro video"
        },
        "uzbek": {
            "🇺🇿 O'zbekcha": "🇺🇿 O'zbek video",
            "🇷🇺 Русский": "🇺🇿 Узбекское видео",
            "🇬🇧 English": "🇺🇿 Uzbek video"
        },
        "orqaga": {
            "🇺🇿 O'zbekcha": "⬅️ Orqaga",
            "🇷🇺 Русский": "⬅️ Назад",
            "🇬🇧 English": "⬅️ Back"
        }
    }

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton(tarjimalar["oddiy"][til])
    btn2 = types.KeyboardButton(tarjimalar["kattalar"][til])
    btn3 = types.KeyboardButton(tarjimalar["pro"][til])
    btn4 = types.KeyboardButton(tarjimalar["uzbek"][til])
    orqaga_btn = types.KeyboardButton(tarjimalar["orqaga"][til])
    markup.add(btn1, btn2, btn3, btn4, orqaga_btn)

    bot.send_message(chat_id, tarjimalar["kategoriyalar"][til], reply_markup=markup)


# Orqaga tugmasi handleri
@bot.message_handler(func=lambda message: message.text in ["⬅️ Orqaga", "⬅️ Назад", "⬅️ Back"])
def asosiy_menyuga_qaytish(message):
    chat_id = message.chat.id
    til = foydalanuvchi_tilini_ol(chat_id)

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton(tarjima_ol("premium_tugmasi", til))
    btn2 = types.KeyboardButton(tarjima_ol("videolar_tugmasi", til))
    markup.add(btn1, btn2)

    bot.send_message(chat_id, tarjima_ol("xush_kelibsiz", til), reply_markup=markup)


# Oddiy video handleri
@bot.message_handler(func=lambda message: message.text in ["📹 Oddiy video", "📹 Обычное видео", "📹 Regular video"])
def oddiy_videolarni_korsat(message):
    chat_id = message.chat.id
    til = foydalanuvchi_tilini_ol(chat_id)

    yuklanmoqda_matni = {
        "🇺🇿 O'zbekcha": "Oddiy videolar yuklanmoqda...",
        "🇷🇺 Русский": "Загружаю обычные видео...",
        "🇬🇧 English": "Loading regular videos..."
    }

    tugma_matni = {
        "🇺🇿 O'zbekcha": "📹 Videolarni ko'rish",
        "🇷🇺 Русский": "📹 Смотреть видео",
        "🇬🇧 English": "📹 Watch videos"
    }

    bot.send_message(chat_id, yuklanmoqda_matni[til])

    markup = types.InlineKeyboardMarkup()
    btn = types.InlineKeyboardButton(
        text=tugma_matni[til],
        web_app=types.WebAppInfo(url="https://tyler-brown.com/video/kinolar")
    )
    markup.add(btn)

    bot.send_message(chat_id, "👉", reply_markup=markup)


# Premium kontent handlerlari
@bot.message_handler(func=lambda message: message.text in [
    "🔞 18+ video", "🔞 18+ видео", "🔞 18+ video",
    "💎 Pro video", "💎 Pro видео", "💎 Pro video",
    "🇺🇿 O'zbek video", "🇺🇿 Узбекское видео", "🇺🇿 Uzbek video"
])
def premium_kontentni_boshqarish(message):
    chat_id = message.chat.id
    til = foydalanuvchi_tilini_ol(chat_id)

    if user_data.get(chat_id, {}).get('premium', False) and user_data[chat_id].get('premium_muddati', 0) > time.time():
        # Premium obunasi bor
        yuklanmoqda_matni = {
            "🇺🇿 O'zbekcha": "Premium kontent ochilmoqda...",
            "🇷🇺 Русский": "Открываю премиум контент...",
            "🇬🇧 English": "Opening premium content..."
        }

        tugma_matni = {
            "18+": {
                "🇺🇿 O'zbekcha": "🔞 Ko'rish",
                "🇷🇺 Русский": "🔞 Смотреть",
                "🇬🇧 English": "🔞 View"
            },
            "pro": {
                "🇺🇿 O'zbekcha": "💎 Ko'rish",
                "🇷🇺 Русский": "💎 Смотреть",
                "🇬🇧 English": "💎 View"
            },
            "uzbek": {
                "🇺🇿 O'zbekcha": "🇺🇿 Ko'rish",
                "🇷🇺 Русский": "🇺🇿 Смотреть",
                "🇬🇧 English": "🇺🇿 View"
            }
        }

        bot.send_message(chat_id, yuklanmoqda_matni[til])

        # Kontent turini aniqlash
        if "18+" in message.text:
            kontent_url = "https://sexy.huyamba.info/search/porno-kino/"
            btn_matn = tugma_matni["18+"][til]
        elif "Pro" in message.text:
            kontent_url = "https://mobi.24videos.cc/search/?text=Porno%20kinolar"
            btn_matn = tugma_matni["pro"][til]
        else:
            kontent_url = "https://z.uz-video.top/videos/uz-porn/"
            btn_matn = tugma_matni["uzbek"][til]

        markup = types.InlineKeyboardMarkup()
        btn = types.InlineKeyboardButton(text=btn_matn, web_app=types.WebAppInfo(url=kontent_url))
        markup.add(btn)

        bot.send_message(chat_id, "👉", reply_markup=markup)
    else:
        # Premium obunasi yo'q
        premium_matni = {
            "🇺🇿 O'zbekcha": (
                f"Premium kontentga kirish uchun {PREMIUM_NARXI} Telegram Stars to'lov qilishingiz kerak. "
                "Bu to'lov sizga 1 oy muddatga barcha premium kontentga kirish imkonini beradi."
            ),
            "🇷🇺 Русский": (
                f"Для доступа к премиум контенту необходимо оплатить {PREMIUM_NARXI} Telegram Stars. "
                "Эта оплата дает вам доступ ко всему премиум контенту на 1 месяц."
            ),
            "🇬🇧 English": (
                f"To access premium content, you need to pay {PREMIUM_NARXI} Telegram Stars. "
                "This payment gives you access to all premium content for 1 month."
            )
        }

        tolov_tugmasi = {
            "🇺🇿 O'zbekcha": "💳 Premiumga obuna bo'lish",
            "🇷🇺 Русский": "💳 Подписаться на премиум",
            "🇬🇧 English": "💳 Subscribe to premium"
        }

        markup = types.InlineKeyboardMarkup()
        tolov_btn = types.InlineKeyboardButton(tolov_tugmasi[til], callback_data="premium_tolov")
        markup.add(tolov_btn)

        bot.send_message(chat_id, premium_matni[til], reply_markup=markup)


# Premium obuna handleri
@bot.message_handler(
    func=lambda message: message.text in ["💳 Premium obuna", "💳 Премиум подписка", "💳 Premium subscription"])
def premium_obuna_taklif(message):
    chat_id = message.chat.id
    til = foydalanuvchi_tilini_ol(chat_id)

    premium_malumot = {
        "🇺🇿 O'zbekcha": (
            f"Premium obuna - {PREMIUM_NARXI} Telegram Stars\n\n"
            "Obuna haqqi 1 oy muddatga amal qiladi va quyidagi imkoniyatlarni beradi:\n"
            "- Barcha premium videolar (18+, Pro, O'zbek)\n"
            "- Cheksiz kirish imkoniyati\n"
            "- Qo'shimcha funksiyalar"
        ),
        "🇷🇺 Русский": (
            f"Премиум подписка - {PREMIUM_NARXI} Telegram Stars\n\n"
            "Подписка действует 1 месяц и дает следующие возможности:\n"
            "- Все премиум видео (18+, Pro, Узбекские)\n"
            "- Неограниченный доступ\n"
            "- Дополнительные функции"
        ),
        "🇬🇧 English": (
            f"Premium subscription - {PREMIUM_NARXI} Telegram Stars\n\n"
            "The subscription is valid for 1 month and provides:\n"
            "- All premium videos (18+, Pro, Uzbek)\n"
            "- Unlimited access\n"
            "- Additional features"
        )
    }

    obuna_tugmasi = {
        "🇺🇿 O'zbekcha": "💳 Obuna bo'lish",
        "🇷🇺 Русский": "💳 Подписаться",
        "🇬🇧 English": "💳 Subscribe"
    }

    markup = types.InlineKeyboardMarkup()
    tolov_btn = types.InlineKeyboardButton(obuna_tugmasi[til], callback_data="premium_tolov")
    markup.add(tolov_btn)

    bot.send_message(chat_id, premium_malumot[til], reply_markup=markup)


# Premium to'lov handleri
@bot.callback_query_handler(func=lambda call: call.data == "premium_tolov")
def premium_tolovini_boshqarish(call):
    chat_id = call.message.chat.id
    til = foydalanuvchi_tilini_ol(chat_id)

    tolov_matni = {
        "sarlavha": {
            "🇺🇿 O'zbekcha": "Premium obuna",
            "🇷🇺 Русский": "Премиум подписка",
            "🇬🇧 English": "Premium subscription"
        },
        "tavsif": {
            "🇺🇿 O'zbekcha": "1 oylik premium obuna uchun to'lov",
            "🇷🇺 Русский": "Оплата за 1 месяц премиум подписки",
            "🇬🇧 English": "Payment for 1 month premium subscription"
        }
    }

    try:
        bot.send_invoice(
            chat_id=chat_id,
            title=tolov_matni["sarlavha"][til],
            description=tolov_matni["tavsif"][til],
            invoice_payload="premium_obuna",
            provider_token="",  # To'lov provayder tokenini qo'ying
            currency="XTR",
            prices=[types.LabeledPrice("Premium Access", PREMIUM_NARXI * 100)]  # Centga aylantirish
        )
    except Exception as xato:
        bot.send_message(chat_id, f"Xato: {str(xato)}")


@bot.pre_checkout_query_handler(func=lambda query: True)
def tolovni_tekshirish(pre_checkout_query):
    bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)


@bot.message_handler(content_types=['successful_payment'])
def muvaffaqiyatli_tolov(message):
    chat_id = message.chat.id
    til = foydalanuvchi_tilini_ol(chat_id)

    # 1 oylik premium obuna berish (30 kun)
    user_data[chat_id]['premium'] = True
    user_data[chat_id]['premium_muddati'] = time.time() + (30 * 24 * 60 * 60)

    muvaffaqiyat_matni = {
        "🇺🇿 O'zbekcha": (
            "Premium obuna muvaffaqiyatli sotib olindi! Endi barcha premium kontentga kirishingiz mumkin.\n\n"
            "Obuna muddati: 1 oy"
        ),
        "🇷🇺 Русский": (
            "Премиум подписка успешно приобретена! Теперь у вас есть доступ ко всему премиум контенту.\n\n"
            "Срок подписки: 1 месяц"
        ),
        "🇬🇧 English": (
            "Premium subscription purchased successfully! You now have access to all premium content.\n\n"
            "Subscription period: 1 month"
        )
    }

    bot.reply_to(message, muvaffaqiyat_matni[til])


# Admin paneli
@bot.message_handler(commands=['admin'])
def admin_paneli(message):
    chat_id = message.chat.id

    if chat_id not in ADMIN_IDS:
        bot.reply_to(message, "Sizda admin huquqlari yo'q.")
        return

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    for buyruq in admin_buyruqlari:
        markup.add(types.KeyboardButton(f"/{buyruq}"))

    bot.send_message(chat_id, "Admin paneli:", reply_markup=markup)


@bot.message_handler(commands=['stats'])
def statistikani_korsat(message):
    chat_id = message.chat.id

    if chat_id not in ADMIN_IDS:
        return

    jami_foydalanuvchilar = len(user_data)
    premium_foydalanuvchilar = sum(1 for foydalanuvchi in user_data.values() if foydalanuvchi.get('premium', False))

    statistikalar = (
        f"📊 Bot statistikasi:\n"
        f"👥 Jami foydalanuvchilar: {jami_foydalanuvchilar}\n"
        f"💎 Premium foydalanuvchilar: {premium_foydalanuvchilar}\n"
        f"📈 Premium foizi: {premium_foydalanuvchilar / jami_foydalanuvchilar * 100:.1f}%"
    )

    bot.reply_to(message, statistikalar)


@bot.message_handler(commands=['broadcast'])
def broadcastni_boshlash(message):
    chat_id = message.chat.id

    if chat_id not in ADMIN_IDS:
        return

    xabar = bot.reply_to(message, "Barcha foydalanuvchilarga yubormoqchi bo'lgan xabaringizni yuboring:")
    bot.register_next_step_handler(xabar, broadcastni_yuborish)


def broadcastni_yuborish(message):
    chat_id = message.chat.id
    broadcast_matni = message.text

    if chat_id not in ADMIN_IDS:
        return

    bot.reply_to(message, f"Xabar {len(user_data)} ta foydalanuvchiga yuborilmoqda...")

    muvaffaqiyatli = 0
    xatolar = 0

    for foydalanuvchi_id in user_data:
        try:
            bot.send_message(foydalanuvchi_id, broadcast_matni)
            muvaffaqiyatli += 1
        except Exception as e:
            xatolar += 1

    bot.reply_to(message, f"Xabar yuborish yakunlandi!\nMuvaffaqiyatli: {muvaffaqiyatli}\nXatolar: {xatolar}")


@bot.message_handler(commands=['add_premium'])
def premium_qoshish(message):
    chat_id = message.chat.id

    if chat_id not in ADMIN_IDS:
        return

    xabar = bot.reply_to(message, "Premium berish uchun foydalanuvchi ID sini yuboring:")
    bot.register_next_step_handler(xabar, premium_qoshishni_yakunlash)


def premium_qoshishni_yakunlash(message):
    chat_id = message.chat.id
    admin_id = message.chat.id

    if admin_id not in ADMIN_IDS:
        return

    try:
        foydalanuvchi_id = int(message.text)
        if foydalanuvchi_id not in user_data:
            user_data[foydalanuvchi_id] = {}

        user_data[foydalanuvchi_id]['premium'] = True
        user_data[foydalanuvchi_id]['premium_muddati'] = time.time() + (30 * 24 * 60 * 60)

        bot.send_message(foydalanuvchi_id, "Admin sizga premium obunani berdi!")
        bot.reply_to(message, f"{foydalanuvchi_id} foydalanuvchiga premium muvaffaqiyatli qo'shildi")
    except ValueError:
        bot.reply_to(message, "Noto'g'ri foydalanuvchi ID si. Raqamli ID yuboring.")


def botni_ishlat():
    """Botni ishga tushirish va xatolarni boshqarish"""
    maks_qayta_urish = 5
    qayta_urish_oraliq = 15

    for urinish in range(maks_qayta_urish):
        try:
            # Webhook faol emasligiga ishonch hosil qilish
            webhookni_ochir()

            print("Bot polling rejimida ishga tushirilmoqda...")
            bot.polling(none_stop=True, interval=3, timeout=20)

        except Exception as xato:
            print(f"{urinish + 1}-urinish muvaffaqiyatsiz yakunlandi. Xato: {str(xato)}")
            if urinish < maks_qayta_urish - 1:
                print(f"{qayta_urish_oraliq} soniyadan keyin qayta uriniladi...")
                time.sleep(qayta_urish_oraliq)
                qayta_urish_oraliq *= 2  # Orttirma oraliq
            else:
                print("Maksimal qayta urinishlar soniga yetildi. Dastur tugatiladi.")
                raise


if __name__ == "__main__":
    print("Bot ishga tushirilmoqda...")
    try:
        botni_ishlat()
    except KeyboardInterrupt:
        print("Bot foydalanuvchi tomonidan to'xtatildi")
    except Exception as xato:
        print(f"Jiddiy xato: {xato}")